def get_data():
	return {
		"fieldname": "employee_onboarding_template",
		"transactions": [
			{"items": ["Employee Onboarding"]},
		],
	}
