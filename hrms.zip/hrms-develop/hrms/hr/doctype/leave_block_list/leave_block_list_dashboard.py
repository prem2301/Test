def get_data():
	return {"fieldname": "leave_block_list", "transactions": [{"items": ["Department"]}]}
