# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors and Contributors
# See license.txt

from frappe.tests.utils import FrappeTestCase

# test_records = frappe.get_test_records('Expense Claim Type')


class TestExpenseClaimType(FrappeTestCase):
	pass
