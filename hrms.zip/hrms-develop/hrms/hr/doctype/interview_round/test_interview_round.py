# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

from frappe.tests.utils import FrappeTestCase

# import frappe


class TestInterviewRound(FrappeTestCase):
	pass
