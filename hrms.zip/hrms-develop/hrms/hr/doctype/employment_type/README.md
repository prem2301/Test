Type of employment.

e.g. Permanent, Probation, Intern etc.