from frappe import _


def get_data():
	return [{"module_name": "HRMS", "type": "module", "label": _("HRMS")}]
